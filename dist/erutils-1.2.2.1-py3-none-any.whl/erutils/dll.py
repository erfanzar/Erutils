
import pefile
import glob
import os
import shutil
from typing import Union


