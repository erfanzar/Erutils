import sys


def main():
    print(f'[ACTION] : [PACKAGE RUNNING] -> {sys.version} -> {sys.version_info} => [erutils]')


if __name__ == "__main__":
    main()
