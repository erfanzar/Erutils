# `Erutils`

The `Erutils` package is the most simple package that include some stuffs that i think that i use every day and build them every day cause im to lazy to copy them from other projects :).


Erutils Package is a self made package for self uses but if you find a way to use it to make you job easier.

feel free to use as you wish but for a simple introduction erutils have 4 fls and those are .


'cli' , 'dll' ,' lightning(AI)' , 'utils', 'nlp' .


# 'cli'
*'cli'* is used for command line interface .


# 'dll'
*'dll'* for dll file problems cause i ran into a lot of em .


# 'lightning'
*'lightning'* some classes and functions that i think that i always use like iou kmeans and many more ... .


# 'utils'
*'utils'* some functions like downloader timeSince and some more ... .
