# `Erutils`

The `Erutils` package is the most simple package that include some stuffs that i think that i use every day and build them every day cause im to lazy to copy them from other projects :). 
