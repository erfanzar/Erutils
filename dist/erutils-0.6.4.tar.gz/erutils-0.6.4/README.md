# `Erutils`

The `Erutils` package is the most simple package that include some stuffs that i think that i use every day and build them every day cause im to lazy to copy them from other projects :).


Erutils Package is a self made package for self uses but if you find a way to use it to make you job easier.

feel free to use as you wish but for a simple introduction erutils have 4 fls and those are .

Open [erfanzare Github](https://github.com/erfanzar/)

Open [Package Github](https://github.com/erfanzar/Erutils)


`command line inteface`  `dll` ` lightning(AI)`  `utils` `nlp` `neurons` .
    

### `command line inteface`
*command line inteface* is used for command line interface with functions like.\
show_array   arrays between 0 - 255 to image show\
draw_rec   plot rectangle with given informations\
Cp   colors cli\
fprint\
attar_print\
print_model\
Logger   class Logger


### `dll`
*dll* for dll file problems cause i ran into a lot of em .


### `lightning`
*lightning* some classes and functions that i think that i always use like iou kmeans and many more ... .
arg_creator   to create args for modules from a list\
pars_model_v2   to create model with config passed to\
pars_model   same as pars_model_v2 but older and have less options\
max_args_to_max_non_tom   one hot encoding\
max_args_to_one_arg\
accuracy\
is_parallel    Returns True if model is of type DP or DDP\
de_parallel   De-parallelize a model returns single-GPU model if model is of type DP or DDP\
name_to_layer\
module_creator   used for objd\
attr_exist_check_   check if attr exist in anyclass\
iou\
bbox_iou   updated iou\
avg_iou\
TorchBaseModule   torch train based module with some new capeblities\
M   torch module based module with some new features

### `utils`
*utils* some functions like downloader timeSince and some more ... .
as_minutes\
time_since\
read_video\
write_video_frame\
download\
read_yaml\
read_json\
read_txt\
str_to_list\
wrd_print\
read_toml\
mp4_to_mp3

### `neurons`
*neurons* some customized neural networks for pytorch line Convs and etc .
Conv\
Concat\
Neck\
C3\
C4P\
RepConv\
ConvSc\
ResidualBlock\
CV1\
UC1\
MP\
SP\
LP\
UpSample\
SPPCSPC

### `nlp`
*nlp* not fully complited but have classes and functions for text preprocessing .\
Lang   class for tokenize words like (add to vocab index2token and etc)\
normalize_string \
unicode_to_ascii


## 🚀 About Me

Hi there 👋
I like to train deep neural nets on large datasets 🧠.
Among other things in this world:)

## License

[MIT](https://choosealicense.com/licenses/mit/)

## Used By

Private Project

## Author

- [@erfanzar](https://www.github.com/erfanzar)